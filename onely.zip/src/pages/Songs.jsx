import React from 'react'

const Songs = () => {
    return (
        <div>
              <h1>Songs</h1>
        </div>
    )
}

export default Songs
