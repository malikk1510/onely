import React from 'react'

const Podcast = () => {
    return (
        <div>
              <h1>Podcast</h1>
        </div>
    )
}

export default Podcast
