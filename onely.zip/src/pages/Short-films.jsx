import React from 'react'

const ShortFilms = () => {
    return (
        <div>
              <h1>Short-Films</h1>
        </div>
    )
}

export default ShortFilms
