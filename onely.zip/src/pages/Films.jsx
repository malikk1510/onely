import React from 'react'

const Films = () => {
    return (
        <div>
            <h1>Films</h1>
        </div>
    )
}

export default Films
