import React from 'react'

const Drama = () => {
    return (
        <div>
              <h1>Drama</h1>
        </div>
    )
}

export default Drama
