import React from 'react'

const Books = () => {
    return (
        <div>
            <h1>books</h1>
        </div>
    )
}

export default Books
